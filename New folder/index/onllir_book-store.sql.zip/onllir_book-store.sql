-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 21, 2021 at 07:35 AM
-- Server version: 5.7.28-cll-lve
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onllir_book-store`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_ip` text COLLATE utf8_persian_ci NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_ip`, `product_id`) VALUES
(32, '83.122.18.65', 14),
(31, '5.213.2.222', 2),
(28, '5.212.14.151', 10),
(33, '83.122.18.65', 2),
(34, '83.122.18.65', 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'UniversityBooks'),
(2, 'generalBooks'),
(3, 'psychologyBooks');

-- --------------------------------------------------------

--
-- Table structure for table `commentes`
--

CREATE TABLE `commentes` (
  `id` int(11) NOT NULL,
  `username` text COLLATE utf8_persian_ci NOT NULL,
  `user_email` text COLLATE utf8_persian_ci NOT NULL,
  `comment_text` text COLLATE utf8_persian_ci NOT NULL,
  `is_confirm` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `commentes`
--

INSERT INTO `commentes` (`id`, `username`, `user_email`, `comment_text`, `is_confirm`) VALUES
(1, 'حمیده', 'hamideh@gmail.com', 'ارسال به موقع', 1),
(2, 'مهدی', 'mahdi@gmail.com', 'ارسال صحیح و به موقع...ممنون از خدمات دهی عالیتون', 1),
(4, 'حنانه', 'hananeh@gmail.com', 'خوب بود', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `total` float NOT NULL,
  `product_ids` text COLLATE utf8_persian_ci NOT NULL,
  `user_email` text COLLATE utf8_persian_ci NOT NULL,
  `is_paid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `total`, `product_ids`, `user_email`, `is_paid`) VALUES
(3, 660000, '10,19,', 'hamideh@gmail.com', 1),
(7, 930000, '11,12,10,19,', 'hamid@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `product_name` text COLLATE utf8_persian_ci NOT NULL,
  `product_price` float NOT NULL,
  `product_desc` text COLLATE utf8_persian_ci NOT NULL,
  `product_image` text COLLATE utf8_persian_ci NOT NULL,
  `sell_num` int(11) DEFAULT NULL,
  `product_discount` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `product_name`, `product_price`, `product_desc`, `product_image`, `sell_num`, `product_discount`) VALUES
(2, 1, 'نظریه زبان ها و ماشین ها', 180000, '(Peter , Linz)نوشته: پیتر و لینز\r\nترجمه : دکتر عبدالحسین صراف زاده\r\nانتشارات ناقوس', 'NAZARIEH.jpg', 12, NULL),
(10, 1, 'رویکردی نوین در هوش مصنوعی (جلد اول)', 600000, 'نوشته:استوارت راسل،پیتر نورویگ\r\nترجمه:سعید راحتی،محمد بهداد،مجیدغفوری،آزاده کامل قالی باف،\r\nریحانه معارف دوست', 'Hoosh.jpg', NULL, 1),
(4, 1, 'تحلیل رفتار سیالات دو فازی', 180000, 'نوشته:سعید نیازخانی', 'Tahlil.jpg', 0, NULL),
(5, 1, 'اینترنت', 120000, 'نوشته:سعیده مفیدی نسب', 'enternet.jpg', 11, NULL),
(6, 1, 'بانک اطلاعات علمی کاربردی', 140000, 'نوشته : مصطفی حق جو و احمد فراهی\r\nانتشارات : دانشگاه علم و صنعت ایران', 'PaygahDadeh.jpg', 0, 1),
(7, 1, 'حل المسائل پایتون', 195000, 'نوشته:رمضان عباس نژادورزی، محمد نادعلی زاده چاری، یوسف عباس نژادورزی', 'HaleMasaelPython.JPG', 0, NULL),
(8, 1, 'الگوریم و فلوچارت', 80000, 'نوشته:افشین امینی و عبدالحمید جهانگیری', 'algoritm.jpg', 0, NULL),
(9, 1, 'EXCELکلیدترفندهای', 90000, 'نوشته:محمدتقی مروج', 'Excel.jpg', 0, NULL),
(11, 2, 'خیابان کاتالین', 150000, 'نوشته:ماگدا ساب،نصرالله مرادیانی', 'khiabanKatalin.jpg', NULL, NULL),
(12, 2, 'گفتار زردشت', 120000, 'نوشته:رضا رامز\r\nراوی:نسترن حسنی', 'GoftarZardosht.jpg', NULL, 1),
(13, 2, 'گذرگاه زندگی', 80000, 'نوشته:سارا هاپ\r\nترجمه:شباهنگ دلشاد', 'Gozargah.jpg', NULL, NULL),
(14, 2, 'نبرد من', 300000, 'نوشته : فرشته اکبر پور', 'Nabard man.jpg', NULL, 1),
(15, 2, 'جزء از کل', 225000, 'نوشته:استیو تولتز،،معصومه محمودی', 'Joze az kol.jpg', NULL, NULL),
(16, 2, 'الهه عشق با بالهای کاغذی', 190000, 'نوشته:صدف محسنی،رافائل ژیوردانو', 'ElaheEshghBaBalhayeKaghzi.jpg', NULL, 1),
(17, 2, 'سیزده', 200000, 'نوشته:علی میر صادقی', 'Sizdah.jpg', NULL, NULL),
(18, 2, 'ظلم و سکوت ', 40000, 'نوشته:مصطفی علی اکبر نیشابوری', 'Zolm va sokot.jpg', 15, NULL),
(19, 3, 'جادوی نظم', 60000, 'نوشته:ماری کندو،گلسا دیبا', 'Jadoy nazm.jpg ', 20, NULL),
(20, 3, 'آتش درون', 300000, 'نوشته:غزال رامزبان', 'AtashDaroon.jpg', NULL, 1),
(24, 3, 'رنگ شناسی', 200000, 'نوشته : سحر مفیدی ، محمدرضا مفیدی', 'RangShenasi.jpg', NULL, NULL),
(22, 3, 'آرامش ذهن', 100000, 'نوشته:اعظم صادقیان', 'ArameshZehn.jpg', 11, NULL),
(23, 3, 'سی گام خود سازی بر پایه دعاهای ماه مبارک رمضان', 35000, 'نوشته:محمود صلواتی', '30GamKhodSazi.jpg', NULL, 1),
(25, 3, 'سفر روح', 200000, 'نوشته : مایکل نیوتن ، محمود دانایی\r\nانتشارات : نیکو نشر', 'safarRoh.jpg', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `display_name` text COLLATE utf8_persian_ci NOT NULL,
  `email` text COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `password` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `display_name`, `email`, `address`, `password`) VALUES
(2, 'حمیده ', 'hamideh@gmail.com', 'فارس-نی ریز', '81dc9bdb52d04dc20036dbd8313ed055'),
(3, 'حنانه ', 'hananeh@gmail.com', '', 'e82c4b19b8151ddc25d4d93baf7b908f'),
(4, 'مهدی ', 'mahdi@gmail.com', '', '81dc9bdb52d04dc20036dbd8313ed055'),
(5, 'حمید ', 'hamid@gmail.com', 'فارس-شیراز', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `commentes`
--
ALTER TABLE `commentes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `commentes`
--
ALTER TABLE `commentes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
